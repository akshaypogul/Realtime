#!/usr/bin/env python
# coding: utf-8

# In[ ]:


get_ipython().system('pip install boto3')
get_ipython().system('pip install yfinance')
get_ipython().system('pip install yahoofinancials')


# In[ ]:


import boto3
import pandas as pd
from io import StringIO
import datetime
from datetime import date,time,datetime,timedelta
import yfinance
import yfinance as yf
from yahoofinancials import YahooFinancials as yf
import yfinance as yc
import io


# In[ ]:


def read_equity_data(path):
      data=pd.read_excel(path,sheet_name='Sheet1')
      return(data)
def get_data(company_symbol):
      stock_data=pd.DataFrame(yc.download(company_symbol,start=date.today(),end=date.today()+timedelta(days=1),interval="1m",progress=True)).reset_index()
      current_price=yf([company_symbol]).get_current_price()
      high_year=yf([company_symbol]).get_yearly_high()
      low_year=yf([company_symbol]).get_yearly_low()
      current_time=str(datetime.now())
      # col_name=current_time+"_price"
      stock_data["current_price"]=[current_price[company_symbol]]*len(stock_data)
      stock_data["high_52"]=[high_year[company_symbol]]*len(stock_data)
      stock_data["low_52"]=[low_year[company_symbol]]*len(stock_data)
      stock_data["BSE"]=[company_symbol]*len(stock_data)
      return(stock_data)


# In[ ]:


get_ipython().run_cell_magic('time', '', 'equity_data=read_equity_data("C:/Users/Ganesh/Downloads/Recent2.xlsx")\nall_companies=[]\ncompanies_symbols=equity_data[\'BSE\'].unique()\nfor comapany_symbol in (companies_symbols):\n    try:\n        company_data=get_data(comapany_symbol)\n        all_companies.append(company_data)\n    except Exception as e:\n        print(e)\n        #pass\nall_data=pd.concat(all_companies,axis=0)\nfinal_data=equity_data.merge(all_data,on=["BSE"],how="outer")\nfinal_data.to_csv("D:/realtimestockdata/21sept22.csv" )')


# In[ ]:


import boto3
get_ipython().system('pip install s3fs')
import s3fs
s3_resource=boto3.client('s3')
final_data.to_csv("s3://realtimestockdata/stock_data/"+date_time)


# In[ ]:


from datetime import datetime
import pytz

datetime_india = datetime.now(pytz.timezone('Asia/Kolkata'))
print("Formatted DateTime in IST : ", datetime_india.strftime('%Y:%m:%d %H:%M:%S %Z %z'))
date_time=str(datetime_india.strftime('%Y:%m:%d %H:%M:%S %Z %z'))
file_path = "s3://realtimestockdata/final_report/"+date_time


# In[ ]:


# Alternate Method
def get_company_data():
    client=boto3.client('s3')
    object_file = client.get_object(Bucket='realtimecompanylist', Key='Recent2.xlsx')
    body = object_file['Body'].read()
    df = pd.read_excel(io.BytesIO(body),sheet_name='Sheet1')
    return(df)

def get_data(company_symbol):
      stock_data=pd.DataFrame(yc.download(company_symbol,start=date.today(),end=date.today()+timedelta(days=1),interval="1m",progress=True)).reset_index()
      current_price=yf([company_symbol]).get_current_price()
      high_year=yf([company_symbol]).get_yearly_high()
      low_year=yf([company_symbol]).get_yearly_low()
      current_time=str(datetime.now())
      # col_name=current_time+"_price"
      stock_data["current_price"]=[current_price[company_symbol]]*len(stock_data)
      stock_data["Low_52"]=[low_year[company_symbol]]*len(stock_data)
      stock_data["High_52"]=[high_year[company_symbol]]*len(stock_data)
      stock_data["BSE"]=[company_symbol]*len(stock_data)
      return(stock_data)


def create_final_data():
    equity_data=get_company_data()
    all_companies=[]
    companies_symbols=equity_data['BSE'].unique()
    for comapany_symbol in (companies_symbols):
        try:
            company_data=get_data(comapany_symbol)
            all_companies.append(company_data)
        except Exception as e:
            print(e)
        #pass
    all_data=pd.concat(all_companies,axis=0)
    final_data=equity_data.merge(all_data,on=["BSE"],how="outer")
    return(final_data)

def upload_to_s3(dataframe,file_name,bucket_name='realtimestockdata'):
    csv_buffer=StringIO()
    dataframe.to_csv(csv_buffer)
   
    responce=client.put_object(Body=csv_buffer.getvalue(),Bucket=bucket_name,Key=file_name)
    return(responce)

upload_to_s3(create_final_data(),'Realtime_data.csv')

